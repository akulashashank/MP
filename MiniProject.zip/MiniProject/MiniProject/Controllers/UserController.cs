﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using MiniProject.Models;

namespace MiniProject.Controllers
{
    public class UserController : Controller
    {
        RajnikanthEntities raj = new RajnikanthEntities();

        // GET: User
        public ActionResult Index()
        {
            //ViewBag.User = Session["UserName"];
            string role = Session["Role"].ToString();
            if (role == "Customer")
            {
                ViewBag.User = Session["UserName"];
                return View();
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult SearchPolicy()
        {
            if (Session != null)
            {
                string role = Session["Role"].ToString();
                if (role == "Customer")
                {
                    ViewBag.msg = String.Empty;
                    if (TempData.ContainsKey("isRequestAdded"))
                    {
                        int custId = Convert.ToInt32(Session["CustomerId"]);
                        var query = from policy in raj.Policies where policy.Customer.CustomerId == custId select policy;
                        ViewBag.msg = TempData["isRequestAdded"];
                        return View(query.ToList());
                    }
                    return View();
                }
                return RedirectToAction("Login", "Login");
            }
            return RedirectToAction("Login", "Login");
        }

        [HttpPost]
        public ActionResult SearchPolicy(int? Policyno, DateTime? DOB, int? CustomerId)
        {
            string role = Session["Role"].ToString();
            if (Session["Role"].ToString() == "Customer")
            {
                ViewBag.msg = String.Empty;
                if (TempData.ContainsKey("isRequestAdded"))
                {
                    ViewBag.msg = TempData["isRequestAdded"];
                }
                int custId = Convert.ToInt32(Session["CustomerId"]);
                var query = from policy in raj.Policies where policy.Customer.CustomerId == custId select policy;
                if (Policyno != null)
                {
                    query = query.Where(a => a.Policyno == Policyno);
                }
                if (DOB != null)
                {
                    query = query.Where(a => a.Customer.DOB == DOB);
                }
                return View(query.ToList());
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult GetValById(int? Policyno)
        {
            string role = Session["Role"].ToString();
            if (Session["Role"].ToString() == "Customer")
            {
                var res = (from cust in raj.Policies
                           where cust.Policyno == Policyno
                           select new
                           {
                               cust.Policyno,
                               cust.ProductId,
                               cust.NomineeAddress,
                               cust.Nominee,
                               cust.NomineeTelephone,
                               cust.Relation,
                               cust.InsuranceProduct.PremiumPaymentFrequency,
                               cust.InsuranceProduct.ProductName,
                               cust.InsuranceProduct.SumAssured,
                               cust.InsuranceProduct.TotalPayment,
                               cust.InsuranceProduct.TotalPremium,
                               cust.CustomerId
                           }).ToList();
                return Json(res, JsonRequestBehavior.AllowGet);
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult EditPolicy(int? SumAssured,  int? TotalPremium, int? TotalPayment, int? Policyno, HttpPostedFileBase Photo, string Idcard, string PremiumPaymentFrequency, string NomineeAddress, string NomineeTelephone, string Relation, string Nominee, int CustomerId, int ProductId)
        {
            var ress = Request;
            string role = Session["Role"].ToString();
            if (role == "Customer")
            {
                bool isChanged = false;
                var res = raj.Policies.Where(a => a.Policyno == Policyno).First();
                Endorsement endorse = new Endorsement();
                //var cust = (Policy)raj.Policies.Where();
                if (res.InsuranceProduct.SumAssured != SumAssured)
                {
                    isChanged = true;
                    endorse.ChangedSumAssured = Convert.ToDecimal(SumAssured);
                }
                if (res.InsuranceProduct.TotalPremium != TotalPremium)
                {
                    isChanged = true;
                    endorse.ChangedTotalPremium = Convert.ToDecimal(TotalPremium);
                }
                if (res.InsuranceProduct.TotalPayment != TotalPayment)
                {
                    isChanged = true;
                    endorse.ChangedTotalPayment = Convert.ToDecimal(TotalPayment);
                }
                if (res.InsuranceProduct.PremiumPaymentFrequency != PremiumPaymentFrequency)
                {
                    isChanged = true;
                    endorse.ChangedPremiumPaymentFrequency = PremiumPaymentFrequency;
                }
                if (res.NomineeAddress != NomineeAddress)
                {
                    isChanged = true;
                    endorse.ChangedNomineeAddress = NomineeAddress;
                }
                if (res.Nominee != Nominee)
                {
                    isChanged = true;
                    endorse.ChangedNominee = Nominee;
                }
                if (res.NomineeTelephone != NomineeTelephone)
                {
                    isChanged = true;
                    endorse.ChangedNomineeTelephone = NomineeTelephone;
                }
                TempData["policyno"] = Policyno;
                TempData["DOB"] = res.Customer.DOB;
                TempData["Id"] = res.Customer.CustomerId;
                if (isChanged)
                {
                    int count = raj.Endorsements.Count();
                    endorse.EndorsementId = count+1;
                    endorse.Policyno = int.Parse(Policyno.ToString());
                    endorse.CreatedDate = DateTime.Now;
                    endorse.Status = "InProgress";
                    endorse.CustomerId = CustomerId;
                    endorse.ProductId = ProductId;
                    raj.Endorsements.Add(endorse);
                    Document doc = new Document();
                    doc.Policyno = int.Parse(Policyno.ToString());
                    doc.UploadedDate = DateTime.Now;
                    doc.Idcard = Idcard;
                    if (Photo.ContentLength > 0)
                    {
                        var filname = Path.GetFileName(Photo.FileName);
                        var path = Path.Combine(Server.MapPath("~/Content/Images"), filname);
                        Photo.SaveAs(path);
                        doc.Photo = path;
                    }
                    raj.Documents.Add(doc);
                    raj.SaveChanges();
                    TempData["isRequestAdded"] = "true";
                    return RedirectToAction("SearchPolicy");
                }
                TempData["isRequestAdded"] = "false";
                return RedirectToAction("SearchPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult ShowAllRequestedItems()
        {
            if (Session.Count>0)
            {
                string role = Session["Role"].ToString();
                if (role == "Customer")
                {
                    int custId = Convert.ToInt32(Session["CustomerId"]);
                    var query = raj.Endorsements.Where(a => a.CustomerId == custId).ToList();
                    return View(query);
                }
                return RedirectToAction("Login", "Login");
            }
            return RedirectToAction("Login", "Login");
        }
    }
}