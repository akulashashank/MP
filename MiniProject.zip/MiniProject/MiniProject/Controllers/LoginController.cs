﻿using MiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiniProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        RajnikanthEntities raj = new RajnikanthEntities();
        public ActionResult Login()
        {
            ViewBag.Status = true;
            return View();
        }

        [HttpPost]
        public ActionResult Login(Customer cust)
        {
            if (cust.Role == "Customer")
            {
                bool isValid = isValidId(cust.Username);
                if (isValid)
                {
                    var isExists = raj.Customers.Where(a => a.Username == cust.Username && a.Password == cust.Password).FirstOrDefault();
                    if (isExists != null)
                    {
                        Session["UserName"] = isExists.Name;
                        Session["CustomerId"] = isExists.CustomerId;
                        ViewBag.Status = true;
                        Session["Role"] = cust.Role;
                        return RedirectToAction("Index", "User");
                    }
                    else
                    {
                        ViewBag.Status = false;
                        ViewBag.Message = "Password Not Matched";
                        return View();
                    }
                }
                ViewBag.Status = false;
                ViewBag.Message = "CustomerId Not Exists";
                return View();
            }
            return RedirectToAction("AdminLogin");
        }

        public bool isValidId(string Username)
        {
            var isExists = raj.Customers.Where(a => a.Username == Username).FirstOrDefault();
            return isExists != null;
        }

        public ActionResult Register()
        {
            int count  = raj.Customers.Count();
            ViewBag.Count = count+100;
            return View();
        }

        [HttpPost]
        public ActionResult Register(Customer new_customer)
        {
            if (ModelState.IsValid)
            {
                bool isExists = DoesUsernameExists(new_customer.Username);
                if (isExists)
                {
                    int count = raj.Customers.Count();
                    ViewBag.Count = count + 100;
                    ModelState.AddModelError("Username","UserName Already Exists");
                    return View(new_customer);
                }
                else
                {
                    Customer cust = new Customer()
                    {
                        Name = new_customer.Name,
                        Password = new_customer.Password,
                        Telephone = new_customer.Telephone,
                        isSmoker = new_customer.isSmoker,
                        Gender = new_customer.Gender,
                        DOB = new_customer.DOB,
                        CreatedDate = DateTime.Now,
                        Hobbies = new_customer.Hobbies,
                        Address = new_customer.Address,
                        Role = "Customer",
                        Username = new_customer.Username
                    };
                    raj.Customers.Add(cust);
                    raj.SaveChanges();
                    return RedirectToAction("Login");
                }
            }
            else
            {
                int count = raj.Customers.Count();
                ViewBag.Count = count + 100;
                return View();
            }
        }

        public bool DoesUsernameExists(string Username)
        {
            bool status = false;
            var res = raj.Customers.Where(a => a.Username == Username).FirstOrDefault();
            if(res != null)
            {
                status = true;
            }
            return status;
        }

        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Login");
        }

        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdminLogin(Customer admin)
        {
            if (admin.Role == "Admin")
            {
                bool isValid = isValidId(admin.Username);
                if (isValid)
                {
                    var isExists = raj.Customers.Where(a => a.Username == admin.Username && a.Password == admin.Password).FirstOrDefault();
                    if (isExists != null)
                    {
                        Session["UserName"] = isExists.Username;
                        Session["CustomerId"] = admin.CustomerId;
                        Session["Role"] = admin.Role;
                        return RedirectToAction("Index", "Admin");
                    }
                    else
                    {
                        ModelState.AddModelError("Password", "Wrong Password");
                        return View(admin);
                    }
                }
                else
                {
                    ModelState.AddModelError("Username", "Username Not Exists");
                    return View(admin);
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}