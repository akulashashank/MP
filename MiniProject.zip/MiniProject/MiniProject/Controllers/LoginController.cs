﻿using MiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiniProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        RajnikanthEntities raj = new RajnikanthEntities();
        public ActionResult Login()
        {
            ViewBag.Status = true;
            return View();
        }

        [HttpPost]
        public ActionResult Login(Customer cust)
        {
            bool isValid = isValidId(cust.CustomerId);
            if (isValid)
            {
                var isExists = raj.Customers.Where(a => a.CustomerId == cust.CustomerId && a.Password == cust.Password).FirstOrDefault();
                if (isExists != null)
                {
                    Session["UserName"] = isExists.Name;
                    Session["CustomerId"] = cust.CustomerId;
                    ViewBag.Status = true;
                    if (cust.CustomerId == 100)
                    {
                        Session["Role"] = "Admin";
                        return RedirectToAction("Index", "Admin");
                    }
                    else
                    {
                        Session["Role"] = "User";
                        return RedirectToAction("Index", "User");
                    }
                }
                else { 
                    ViewBag.Status = false;
                    ViewBag.Message = "Password Not Matched";
                    return View();
                }
            }
            ViewBag.Status = false;
            ViewBag.Message = "CustomerId Not Exists";
            return View();
        }

        public bool isValidId(int id)
        {
            try
            {
                var isExists = raj.Customers.Where(a => a.CustomerId == id).First();
                return isExists != null;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public ActionResult Register()
        {
            int count  = raj.Customers.Count();
            ViewBag.Count = count+100;
            return View();
        }

        [HttpPost]
        public ActionResult Register(Customer new_customer)
        {
            try
            {
                RajnikanthEntities raj = new RajnikanthEntities();
                Customer cust = new Customer()
                {
                    Name = new_customer.Name,
                    Password = new_customer.Password,
                    Telephone = new_customer.Telephone,
                    isSmoker = new_customer.isSmoker,
                    Gender = new_customer.Gender,
                    DOB = new_customer.DOB,
                    CreatedDate = DateTime.Now,
                    Hobbies = new_customer.Hobbies,
                    Address = new_customer.Address,
                };
                raj.Customers.Add(cust);
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                int count = raj.Customers.Count();
                ViewBag.Count = count + 100;
                return View();
            }
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
    }
}