﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MiniProject.Models;

namespace MiniProject.Controllers
{
    public class AdminController : Controller
    {
        RajnikanthEntities raj = new RajnikanthEntities();

        // GET: Admin
        public ActionResult Index()
        {
            if(Session["Role"].ToString() == "Admin")
            {
                ViewBag.User = Session["UserName"];
                return View();
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult ListAllPolicy()
        {
            if (Session["Role"].ToString() == "Admin")
            {
                ViewBag.ForAlerts = "NotYet";
                if (TempData.ContainsKey("isUpdated"))
                {
                    ViewBag.ForAlerts = TempData["isUpdated"];
                }
                if (TempData.ContainsKey("isDeleted"))
                {
                    ViewBag.ForAlerts = TempData["isDeleted"];
                }
                RajnikanthEntities rajni = new RajnikanthEntities();
                var result = rajni.InsuranceProducts;
                return View(result.ToList());
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult AddNewPolicy(InsuranceProduct newproduct)
        {
            if (Session["Role"].ToString() == "Admin")
            {
                if (ModelState.IsValid)
                {
                    try
                    {
                        RajnikanthEntities rajni = new RajnikanthEntities();
                        newproduct.UplaodedDate = DateTime.Now;
                        rajni.InsuranceProducts.Add(newproduct);
                        rajni.SaveChanges();
                        return RedirectToAction("ListAllPolicy");
                    }
                    catch (Exception ex)
                    {
                        return RedirectToAction("ListAllPolicy");
                    }
                }
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public JsonResult GetValById(int? PolicyNo)
        {
            var res = (from cust in raj.InsuranceProducts where cust.Policyno == PolicyNo select new { cust.TotalPremium,cust.TotalPayment,cust.SumAssured, cust.PremiumPaymentFrequency,cust.Policyno, cust.BasePremium }).ToList();
            //var res = raj.InsuranceProducts.Where(a => a.Policyno == PolicyNo);
            //return Json( new { status = "Success", data = res },JsonRequestBehavior.AllowGet);
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        public ActionResult EditNewPolicy(InsuranceProduct newproduct)
        {
            if (Session["Role"].ToString() == "Admin")
            {
                var ed = (from x in raj.InsuranceProducts
                          where x.Policyno == newproduct.Policyno
                          select x).First();
                ed.ProductName = newproduct.ProductName;
                ed.PremiumPaymentFrequency = newproduct.PremiumPaymentFrequency;
                ed.SumAssured = newproduct.SumAssured;
                ed.TotalPayment = newproduct.TotalPayment;
                ed.TotalPremium = newproduct.TotalPremium;
                ed.BasePremium = newproduct.BasePremium;
                if (TryUpdateModel(ed))
                {
                    raj.SaveChanges();
                    TempData["isUpdated"] = "Updated";
                    return RedirectToAction("ListAllPolicy");
                }
                TempData["isUpdated"] = "error";
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult DeleteSelected(int? Policyno)
        {
            if (Session["Role"].ToString() == "Admin")
            {
                var res = raj.InsuranceProducts.Where(x => x.Policyno == Policyno).First();
                if (res != null)
                {
                    raj.InsuranceProducts.Remove(res);
                    raj.SaveChanges();
                    TempData["isDeleted"] = "Deleted";
                    return RedirectToAction("ListAllPolicy");
                }
                TempData["isDeleted"] = "Error";
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult Endoresements()
        {
            if (Session["Role"].ToString() == "Admin")
            {
                var res = raj.Endorsements.ToList();
                return View(res);
            }
            return RedirectToAction("Login", "Login");
        }

        [HttpPost]
        public ActionResult Endoresements(int EndorsementId, string Status)
        {
            if (Session["Role"].ToString() == "Admin")
            {
                Endorsement endorse = new Endorsement();
                var res = raj.Endorsements.Where(a=>a.EndorsementId == EndorsementId).First();
                res.Status = Status;
                if (res.Status == "Accepted")
                {
                    res.ApprovedDate = DateTime.Now;
                }
                else { res.RejectedDate = DateTime.Now; }
                if(TryUpdateModel(res))
                {
                    raj.SaveChanges();
                    return RedirectToAction("Endoresements");
                }
                return View("Endoresements");
            }
            return RedirectToAction("Login", "Login");
        }
    }
}