﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MiniProject.Models;

namespace MiniProject.Controllers
{
    public class AdminController : Controller
    {
        RajnikanthEntities raj = new RajnikanthEntities();
        // GET: Admin
        public ActionResult Index()
        {
            string role = Session["Role"].ToString();
            if (role == "Admin")
            {
                ViewBag.User = Session["UserName"];
                return View();
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult ListAllPolicy()
        {
            if (Session != null)
            {
                string role = Session["Role"].ToString();
                if (role == "Admin")
                {
                    ViewBag.ForAlerts = "NotYet";

                    if (TempData.ContainsKey("isAdded"))
                    {
                        ViewBag.ForAlerts = TempData["isAdded"];
                    }
                    if (TempData.ContainsKey("isUpdated"))
                    {
                        ViewBag.ForAlerts = TempData["isUpdated"];
                    }
                    if (TempData.ContainsKey("isDeleted"))
                    {
                        ViewBag.ForAlerts = TempData["isDeleted"];
                    }
                    RajnikanthEntities rajni = new RajnikanthEntities();
                    var result = rajni.InsuranceProducts;
                    return View(result.ToList());
                }
                return RedirectToAction("Login", "Login");
            }
            else
            {
                return RedirectToAction("AdminLogin", "Login");
            }
        }

        public ActionResult AddNewPolicy(InsuranceProduct newproduct)
        {
            TempData["IsAdded"] = "error";
            string role = Session["Role"].ToString();
            if (role == "Admin")
            {
                if (ModelState.IsValid)
                {
                    try
                    {
                        RajnikanthEntities rajni = new RajnikanthEntities();
                        newproduct.UplaodedDate = DateTime.Now;
                        rajni.InsuranceProducts.Add(newproduct);
                        rajni.SaveChanges();
                        TempData["IsAdded"] = "Added";
                        return RedirectToAction("ListAllPolicy");
                    }
                    catch (Exception ex)
                    {
                        return RedirectToAction("ListAllPolicy");
                    }
                }
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public JsonResult GetValById(int? PolicyNo)
        {
            var res = (from cust in raj.InsuranceProducts where cust.Policyno == PolicyNo select new { cust.TotalPremium,cust.TotalPayment,cust.SumAssured, cust.PremiumPaymentFrequency,cust.Policyno }).ToList();
            //var res = raj.InsuranceProducts.Where(a => a.Policyno == PolicyNo);
            //return Json( new { status = "Success", data = res },JsonRequestBehavior.AllowGet);
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        public ActionResult EditNewPolicy(InsuranceProduct newproduct)
        {
            string role = Session["Role"].ToString();
            TempData["isUpdated"] = "error";
            if (role == "Admin")
            {
                var ed = (from x in raj.InsuranceProducts
                          where x.Policyno == newproduct.Policyno
                          select x).First();
                ed.ProductName = newproduct.ProductName;
                ed.PremiumPaymentFrequency = newproduct.PremiumPaymentFrequency;
                ed.SumAssured = newproduct.SumAssured;
                ed.TotalPayment = newproduct.TotalPayment;
                ed.TotalPremium = newproduct.TotalPremium;
                if (TryUpdateModel(ed))
                {
                    raj.SaveChanges();
                    TempData["isUpdated"] = "Updated";
                    return RedirectToAction("ListAllPolicy");
                }
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult DeleteSelected(int? Policyno)
        {
            string role = Session["Role"].ToString();
            TempData["isDeleted"] = "error";
            if (role == "Admin")
            {
                var res = raj.InsuranceProducts.Where(x => x.Policyno == Policyno).FirstOrDefault();
                if (res != null)
                {
                    raj.InsuranceProducts.Remove(res);
                    raj.SaveChanges();
                    TempData["isDeleted"] = "Deleted";
                    return RedirectToAction("ListAllPolicy");
                }
                return RedirectToAction("ListAllPolicy");
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult Endoresements()
        {
            string role = Session["Role"].ToString();
            if (role == "Admin")
            {
                var res = raj.Endorsements.ToList();
                var prod = raj.InsuranceProducts.ToList();
                var pol = raj.Policies.ToList();
                var doc = raj.Documents.ToList();
                foreach (var i in res)
                {
                    foreach (var j in prod)
                    {
                        if(i.Policyno == j.Policyno)
                        {
                            i.InsuranceProduct = j;
                        }
                    }
                    foreach (var j in pol)
                    {
                        if(i.ProductId == j.ProductId)
                        {
                            i.Policy = j;
                        }
                    }
                    foreach (var j in doc)
                    {
                        if(i.Policyno == j.Policyno)
                        {
                            i.Document = j;
                        }
                    }
                }
                return View(res);
            }
            return RedirectToAction("Login", "Login");
        }

        [HttpPost]
        public ActionResult Endoresements(int? EndorsementId, string Status, int? SumAssured, int? TotalPayment, int? TotalPremium, string PremiumPaymentFrequency, string Nominee, string NomineeAddress, string NomineeTelephone, string NomineeRelation)
        {
            string role = Session["Role"].ToString();
            if (role == "Admin")
            {
                Endorsement endorse = new Endorsement();
                var res = raj.Endorsements.Where(a => a.EndorsementId == EndorsementId).FirstOrDefault();
                var pol = raj.Policies.Where(a => a.Policyno == res.Policyno).FirstOrDefault();
                var ins_prod = raj.InsuranceProducts.Where(a => a.Policyno == res.Policyno).FirstOrDefault();
                if (Nominee != "")
                {
                    pol.Nominee = Nominee;
                }
                if (NomineeAddress != "")
                {
                    pol.NomineeAddress = NomineeAddress;
                }
                if (NomineeRelation != "")
                {
                    pol.Relation = NomineeRelation;
                }
                if (NomineeTelephone != "")
                {
                    pol.NomineeTelephone = NomineeTelephone;
                }
                if (SumAssured != null)
                {
                    ins_prod.SumAssured = Convert.ToDecimal(SumAssured);
                }
                if (TotalPayment != null)
                {
                    ins_prod.TotalPayment = Convert.ToDecimal(TotalPayment);
                }
                if (TotalPremium != null)
                {
                    ins_prod.TotalPremium = Convert.ToDecimal(TotalPremium);
                }
                if (PremiumPaymentFrequency != "")
                {
                    ins_prod.PremiumPaymentFrequency = PremiumPaymentFrequency;
                }
                res.Status = Status;
                if (res.Status == "Accepted")
                {
                    res.ApprovedDate = DateTime.Now;
                }
                else { res.RejectedDate = DateTime.Now; }
                raj.Entry(ins_prod).State = System.Data.Entity.EntityState.Modified;
                raj.SaveChanges();
                raj.Entry(pol).State = System.Data.Entity.EntityState.Modified;
                raj.SaveChanges();
                raj.Entry(res).State = System.Data.Entity.EntityState.Modified;
                raj.SaveChanges();
                return RedirectToAction("Endoresements");
            }
            return RedirectToAction("Login", "Login");
        }


    }
}